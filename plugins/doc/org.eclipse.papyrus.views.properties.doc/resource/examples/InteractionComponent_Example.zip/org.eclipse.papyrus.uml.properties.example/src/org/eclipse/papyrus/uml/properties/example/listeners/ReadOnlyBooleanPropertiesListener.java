/*****************************************************************************
 * Copyright (c) 2017 CEA LIST and others.
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *   Fanch BONNABESSE (ALL4TEC) fanch.bonnabesse@all4tec.net - Initial API and implementation, Bug 522124
 *   
 *****************************************************************************/

package org.eclipse.papyrus.uml.properties.example.listeners;

import java.util.Set;

import org.eclipse.core.databinding.observable.IObservable;
import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.papyrus.infra.properties.ui.listeners.IPropertiesListener;
import org.eclipse.papyrus.infra.properties.ui.modelelement.DataSource;
import org.eclipse.papyrus.infra.properties.ui.widgets.AbstractPropertyEditor;

/**
 * PropertiesListener to set readonly an editor based on the value of a boolean input.
 * 
 * @since 1.0
 */
public class ReadOnlyBooleanPropertiesListener implements IPropertiesListener {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void handle(final AbstractPropertyEditor editor, final DataSource input, final Set<String> listeningPropertyPaths) {
		boolean isReadOnly = false;
		for (String propertyPath : listeningPropertyPaths) {
			IObservable observable = input.getObservable(propertyPath);

			if (observable instanceof IObservableValue<?>) {
				Object value = ((IObservableValue) observable).getValue();

				if (value instanceof Boolean && value.equals(false)) {
					isReadOnly = true;
				}
			}
		}

		editor.setReadOnly(isReadOnly);
	}

}
