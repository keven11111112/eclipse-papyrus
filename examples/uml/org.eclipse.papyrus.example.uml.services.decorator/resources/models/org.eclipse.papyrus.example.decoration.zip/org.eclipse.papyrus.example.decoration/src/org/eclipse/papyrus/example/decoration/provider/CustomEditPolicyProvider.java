/*****************************************************************************
 * Copyright (c) 2015 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Mickael ADAM (ALL4TEC) mickael.adam@all4tec.net - Initial API and Implementation
 *****************************************************************************/
package org.eclipse.papyrus.example.decoration.provider;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gef.EditPart;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.core.service.IProviderChangeListener;
import org.eclipse.gmf.runtime.diagram.ui.services.editpolicy.CreateEditPoliciesOperation;
import org.eclipse.gmf.runtime.diagram.ui.services.editpolicy.IEditPolicyProvider;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.papyrus.example.decoration.policies.NodeDecoratorEditPolicy;
import org.eclipse.papyrus.infra.gmfdiag.common.editpart.NodeEditPart;
import org.eclipse.uml2.uml.CallBehaviorAction;

/**
 * Edit Policy provider used to load editpolicy which manage papyrus decoration.
 *
 */
public class CustomEditPolicyProvider implements IEditPolicyProvider {

	/** the targeted diagram type */
	protected String diagramType = org.eclipse.papyrus.uml.diagram.activity.edit.parts.ActivityDiagramEditPart.MODEL_ID;

	/**
	 * @see org.eclipse.gmf.runtime.common.core.service.IProvider#addProviderChangeListener(org.eclipse.gmf.runtime.common.core.service.IProviderChangeListener)
	 *
	 * @param listener
	 *            the listener
	 */
	@Override
	public void addProviderChangeListener(final IProviderChangeListener listener) {
	}

	/**
	 * @see org.eclipse.gmf.runtime.common.core.service.IProvider#provides(org.eclipse.gmf.runtime.common.core.service.IOperation)
	 *
	 * @param operation
	 * @return true if it provide a edit policy for this operation.
	 */
	@Override
	public boolean provides(final IOperation operation) {
		boolean provide = false;
		String currentDiagramType;

		// get the element
		final EObject referenceElement = ((View) ((CreateEditPoliciesOperation) operation).getEditPart().getModel()).getElement();

		// Test if it's a creation operation and the element is a CallBehavoirActino
		if (((((CreateEditPoliciesOperation) operation).getEditPart() instanceof NodeEditPart) && (operation instanceof CreateEditPoliciesOperation) && (referenceElement instanceof CallBehaviorAction))) {
			// Get The current diagram type
			currentDiagramType = ((View) ((CreateEditPoliciesOperation) operation).getEditPart().getModel()).getDiagram().getType();
			// Test if we are on an Activity Diagram
			if ((null != diagramType) && (diagramType.equals(currentDiagramType))) {
				provide = true;
			} else {
				provide = false;
			}
		}
		return provide;
	}

	/**
	 * @see org.eclipse.gmf.runtime.common.core.service.IProvider#removeProviderChangeListener(org.eclipse.gmf.runtime.common.core.service.IProviderChangeListener)
	 *
	 * @param listener
	 *            the listener
	 */
	@Override
	public void removeProviderChangeListener(final IProviderChangeListener listener) {
		// Do nothing
	}

	/**
	 * @see org.eclipse.gmf.runtime.diagram.ui.services.editpolicy.IEditPolicyProvider#createEditPolicies(org.eclipse.gef.EditPart)
	 *
	 * @param editPart
	 *            the host edit part
	 */
	@Override
	public void createEditPolicies(final EditPart editPart) {
		editPart.installEditPolicy(NodeDecoratorEditPolicy.EDIT_POLICY_ROLE, new NodeDecoratorEditPolicy());
	}

}
