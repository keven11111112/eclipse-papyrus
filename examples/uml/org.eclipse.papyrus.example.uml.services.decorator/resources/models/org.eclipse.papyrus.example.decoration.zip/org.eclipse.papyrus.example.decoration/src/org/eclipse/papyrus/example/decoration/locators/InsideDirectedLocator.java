/*****************************************************************************
 * Copyright (c) 2015 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Mickael ADAM (ALL4TEC) mickael.adam@all4tec.net - Initial API and Implementation
 *****************************************************************************/
package org.eclipse.papyrus.example.decoration.locators;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Locator;
import org.eclipse.draw2d.geometry.PrecisionRectangle;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.handles.HandleBounds;
import org.eclipse.gmf.runtime.diagram.ui.services.decorator.IDecoratorTarget.Direction;

/**
 * 
 * A custom locator to locate decoration inside the parent which use {@link Direction} to locate.
 * Use for the GMF decoration framework.
 */
public class InsideDirectedLocator implements Locator {

	/** the position of the decoration */
	private final Direction position;

	/** the reference figure */
	private final IFigure reference;

	/**
	 * Constructor.
	 *
	 * @param reference
	 *            the reference figure
	 * @param position
	 *            the position of the decoration
	 */
	public InsideDirectedLocator(final IFigure reference, final Direction position) {
		assert reference != null;
		this.reference = reference;
		this.position = position;
	}

	/**
	 *
	 * @see org.eclipse.draw2d.Locator#relocate(org.eclipse.draw2d.IFigure)
	 *
	 * @param target
	 *            the overlay figure to locate
	 */
	@Override
	public void relocate(final IFigure target) {
		final Rectangle bounds = reference instanceof HandleBounds ? new PrecisionRectangle(((HandleBounds) reference).getHandleBounds()) : new PrecisionRectangle(reference.getBounds());

		reference.translateToAbsolute(bounds);
		target.translateToRelative(bounds);

		final int width = target.getBounds().width;
		final int height = target.getBounds().height;

		final double MARGIN_WIDTH = 3;
		final double MARGIN_HEIGHT = 3;
		if (Direction.NORTH_WEST.equals(this.position)) {
			target.setLocation(bounds.getTopLeft().getTranslated(MARGIN_WIDTH, MARGIN_HEIGHT));
		} else if (Direction.NORTH.equals(this.position)) {
			target.setLocation(bounds.getTop().getTranslated(-width / 2, MARGIN_HEIGHT));
		} else if (Direction.NORTH_EAST.equals(this.position)) {
			target.setLocation(bounds.getTopRight().getTranslated(-MARGIN_WIDTH - width, MARGIN_HEIGHT));
		} else if (Direction.SOUTH_WEST.equals(this.position)) {
			target.setLocation(bounds.getBottomLeft().getTranslated(MARGIN_WIDTH, -MARGIN_HEIGHT - height));
		} else if (Direction.SOUTH.equals(this.position)) {
			target.setLocation(bounds.getBottom().getTranslated(-width / 2, -MARGIN_HEIGHT - height));
		} else if (Direction.SOUTH_EAST.equals(this.position)) {
			target.setLocation(bounds.getBottomRight().getTranslated(-MARGIN_WIDTH - width, -MARGIN_HEIGHT - height));
		} else if (Direction.WEST.equals(this.position)) {
			target.setLocation(bounds.getLeft().getTranslated(MARGIN_WIDTH, -height / 2));
		} else if (Direction.EAST.equals(this.position)) {
			target.setLocation(bounds.getRight().getTranslated(-MARGIN_WIDTH - width, -height / 2));
		} else if (Direction.CENTER.equals(this.position)) {
			target.setLocation(bounds.getCenter().getTranslated(-width / 2, -height / 2));
		}
	}
}