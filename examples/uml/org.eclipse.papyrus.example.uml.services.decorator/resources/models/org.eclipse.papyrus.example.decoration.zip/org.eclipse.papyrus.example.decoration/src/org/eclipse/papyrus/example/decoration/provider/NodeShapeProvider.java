/*****************************************************************************
 * Copyright (c) 2015 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Mickael ADAM (ALL4TEC) mickael.adam@all4tec.net - Initial API and Implementation
 *****************************************************************************/

package org.eclipse.papyrus.example.decoration.provider;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.diagram.core.listener.DiagramEventBroker;
import org.eclipse.gmf.runtime.diagram.core.listener.NotificationListener;
import org.eclipse.gmf.runtime.draw2d.ui.render.RenderedImage;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.papyrus.example.decoration.Activator;
import org.eclipse.papyrus.example.decoration.Utils.ExampleUtils;
import org.eclipse.papyrus.infra.gmfdiag.common.service.shape.AbstractShapeProvider;
import org.eclipse.papyrus.infra.gmfdiag.common.service.shape.ProviderNotificationManager;
import org.eclipse.uml2.uml.CallBehaviorAction;
import org.w3c.dom.svg.SVGDocument;

/**
 * A shape provider for CallBehaviorAction which are allocated the specific stereotyped nodes.
 *
 */
public class NodeShapeProvider extends AbstractShapeProvider {
	// The used SVG files
	private static final String ICONS_SYMBOLS_NODE_A_SVG = "/icons/NodeA.svg";//$NON-NLS-1$
	private static final String ICONS_SYMBOLS_NODE_B_SVG = "/icons/NodeB.svg";//$NON-NLS-1$
	// The notification manager
	private ProviderNotificationManager manager;

	@Override
	public boolean providesShapes(final EObject view) {
		boolean provide = false;
		if (view instanceof View) {
			final EObject element = ((View) view).getElement();
			// Test if the element is a CallBehavoirAction and if a stereotyped node is allocated to it.
			if (element instanceof CallBehaviorAction
					&& (ExampleUtils.isAllocatedTo((CallBehaviorAction) element, ExampleUtils.NODE_A_STEREOTYPE)
							|| ExampleUtils.isAllocatedTo((CallBehaviorAction) element, ExampleUtils.NODE_B_STEREOTYPE))) {
				provide = true;
			} else {
				provide = false;
			}
		}
		return provide;
	}

	/**
	 * @see org.eclipse.papyrus.infra.gmfdiag.common.service.shape.IShapeProvider#getShapes(org.eclipse.emf.ecore.EObject)
	 *
	 * @param view
	 *            the target view
	 * @return the list of rendered images for the view
	 */
	@Override
	public List<RenderedImage> getShapes(final EObject view) {
		if (providesShapes(view)) {
			// Gets the SVG document: here NodeA.svg or/and NodeB.svg
			final List<SVGDocument> documents = getSVGDocument(view);
			if (documents != null) {
				final List<RenderedImage> result = new LinkedList<RenderedImage>();
				for (final SVGDocument document : documents) {
					try {
						// Adds the shape to result
						result.add(renderSVGDocument(view, document));
					} catch (final IOException ex) {
						// Do nothing
					}
				}
				return result;
			}
		}
		return null;
	}

	/**
	 * @see org.eclipse.papyrus.infra.gmfdiag.common.service.shape.IShapeProvider#getSVGDocument(org.eclipse.emf.ecore.EObject)
	 *
	 * @param view
	 *            the target view
	 * @return the list of SVGDocument for the view
	 */
	@Override
	public List<SVGDocument> getSVGDocument(final EObject view) {
		final List<SVGDocument> svgDocuments = new ArrayList<SVGDocument>();
		if (providesShapes(view)) {
			final CallBehaviorAction callBehaviorAction = (CallBehaviorAction) ((View) view).getElement();
			// If allocation corresponding adds SVG document for Node A
			if (ExampleUtils.isAllocatedTo(callBehaviorAction, ExampleUtils.NODE_A_STEREOTYPE)) {
				// Get the SVG document
				final SVGDocument document = getSVGDocument(URI.createPlatformPluginURI(Activator.ID + ICONS_SYMBOLS_NODE_A_SVG, true).toString());
				if (null != document) {
					svgDocuments.add(document);
				}
			}
			// If allocation corresponding adds SVG document for Node B
			if (ExampleUtils.isAllocatedTo(callBehaviorAction, ExampleUtils.NODE_B_STEREOTYPE)) {
				// Get the SVG document
				final SVGDocument document = getSVGDocument(URI.createPlatformPluginURI(Activator.ID + ICONS_SYMBOLS_NODE_B_SVG, true).toString());
				if (null != document) {
					svgDocuments.add(document);
				}
			}
		}
		return svgDocuments;
	}

	/**
	 * @see org.eclipse.papyrus.infra.gmfdiag.common.service.shape.IShapeProvider#createProviderNotificationManager(org.eclipse.gmf.runtime.diagram.core.listener.DiagramEventBroker, org.eclipse.emf.ecore.EObject,
	 *      org.eclipse.gmf.runtime.diagram.core.listener.NotificationListener)
	 *
	 * @param diagramEventBroker
	 *            the diagramEventBroker
	 * @param view
	 *            the view
	 * @param notificationListener
	 *            the notificationListener
	 * @return the provider notification manager
	 */
	@Override
	public ProviderNotificationManager createProviderNotificationManager(final DiagramEventBroker diagramEventBroker, final EObject view, final NotificationListener notificationListener) {
		if (null != manager) {
			return manager;
		}
		manager = new ProviderNotificationManager(diagramEventBroker, view, notificationListener) {
			@Override
			protected void registerListeners() {
				// TODO install listener on allocation(Abstraction) of the model.
			}
		};
		return manager;
	}
}
