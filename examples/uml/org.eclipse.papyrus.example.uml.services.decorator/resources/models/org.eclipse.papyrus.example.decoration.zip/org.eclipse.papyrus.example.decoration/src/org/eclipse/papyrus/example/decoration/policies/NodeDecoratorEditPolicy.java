/*****************************************************************************
 * Copyright (c) 2015 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Mickael ADAM (ALL4TEC) mickael.adam@all4tec.net - Initial API and Implementation
 *****************************************************************************/
package org.eclipse.papyrus.example.decoration.policies;

import org.eclipse.gmf.runtime.gef.ui.internal.editpolicies.GraphicalEditPolicyEx;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.papyrus.example.decoration.Activator;
import org.eclipse.papyrus.example.decoration.NodeAMarker;
import org.eclipse.papyrus.example.decoration.NodeBMarker;
import org.eclipse.papyrus.example.decoration.Utils.ExampleUtils;
import org.eclipse.papyrus.infra.core.services.ServiceException;
import org.eclipse.papyrus.infra.gmfdiag.common.utils.ServiceUtilsForEditPart;
import org.eclipse.papyrus.infra.services.decoration.DecorationService;
import org.eclipse.papyrus.infra.services.decoration.util.Decoration.PreferedPosition;
import org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker;
import org.eclipse.uml2.uml.CallBehaviorAction;

/**
 * Edit policy used to install decoration from papyrus decoration framework
 */
@SuppressWarnings("restriction")
public class NodeDecoratorEditPolicy extends GraphicalEditPolicyEx {

	/**
	 * The Edit Policy Role/ID
	 */
	public static final Object EDIT_POLICY_ROLE = "NODE_A_DECORATOR_KEY"; //$NON-NLS-1$

	/**
	 * Last known value for isExternalReference
	 */
	protected DecorationService decorationService;

	/**
	 * The marker for nodeA
	 */
	protected IPapyrusMarker markerA;

	/**
	 * The marker for nodeB
	 */
	protected IPapyrusMarker markerB;

	/**
	 * true if the node A is already marked
	 */
	private Boolean nodeAMarked = false;

	/**
	 * true if the node B is already marked
	 */
	private Boolean nodeBMarked = false;

	@Override
	public void activate() {
		super.activate();
		// TODO install listener on allocation(Abstraction) of the model.
		try {
			// get the decoration service
			decorationService = ServiceUtilsForEditPart.getInstance().getService(DecorationService.class, getHost());
			refresh();
		} catch (final ServiceException ex) {
			// Ignored; do nothing
		}
	}

	/**
	 * @see org.eclipse.gmf.runtime.gef.ui.internal.editpolicies.GraphicalEditPolicyEx#refresh()
	 *
	 */
	@Override
	public void refresh() {
		final View view = getView();
		if (null == view) {
			return;
		}
		if (null == decorationService) {
			return;
		}

		// If the marker for nodeA already set have to be changed
		if (ExampleUtils.isAllocatedTo((CallBehaviorAction) view.getElement(), ExampleUtils.NODE_A_STEREOTYPE) != nodeAMarked) {
			nodeAMarked = !nodeAMarked;
			if (nodeAMarked) {
				// Decoration With marker
				decorationService.addDecoration(getMarkerA(), getView());
			} else {
				decorationService.removeDecoration(getMarkerA().toString());
			}
			getHost().refresh();
		}
		// If the marker for nodeB already set have to be changed
		if (ExampleUtils.isAllocatedTo((CallBehaviorAction) view.getElement(), ExampleUtils.NODE_B_STEREOTYPE) != nodeBMarked) {
			nodeBMarked = !nodeBMarked;
			if (nodeBMarked) {
				// Decoration for B manage with marker
				// decorationService.addDecoration(getMarkerB(), getView());

				// Or decoration Without marker
				decorationService.addDecoration(
						view.getElement().toString(), // $NON-NLS-1$
						"NodeBDecoration", //$NON-NLS-1$
						view.getElement(),
						org.eclipse.papyrus.infra.widgets.Activator.getDefault().getImageDescriptor(Activator.ID, "icons/NodeB.gif"), //$NON-NLS-1$
						org.eclipse.papyrus.infra.widgets.Activator.getDefault().getImageDescriptor(Activator.ID, "icons/NodeB.gif"), //$NON-NLS-1$ ,
						PreferedPosition.SOUTH_WEST,
						"NodeB decoration Without marker",
						0);

			} else {
				// decorationService.removeDecoration(getMarkerB().toString());
				decorationService.removeDecoration(view.getElement().toString());
			}
			getHost().refresh();
		}
	}

	/**
	 * Returns the marker instance for node A. It is never null
	 *
	 * @return the marker
	 */
	protected IPapyrusMarker getMarkerA() {
		if (null == markerA) {
			// create new marker for node A
			markerA = new NodeAMarker(getView());
		}
		return markerA;
	}

	/**
	 * Returns the marker instance for node A. It is never null
	 *
	 * @return the marker
	 */
	protected IPapyrusMarker getMarkerB() {
		if (null == markerB) {
			// create new marker for node B
			markerB = new NodeBMarker(getView());
		}
		return markerB;
	}

	/**
	 * Return the view associated to this edit policy
	 *
	 * @return
	 */
	protected View getView() {
		return (View) getHost().getModel();
	}

	/**
	 * @see org.eclipse.gef.editpolicies.AbstractEditPolicy#deactivate()
	 *
	 */
	@Override
	public void deactivate() {
		super.deactivate();

		if (null != markerA && null != decorationService) {
			// Remove the marker from the View to avoid duplication
			decorationService.removeDecoration(getMarkerA().toString());
		}
		if (null != markerB && null != decorationService) {
			// Remove the marker from the View to avoid duplication
			decorationService.removeDecoration(getMarkerB().toString());
		}

		markerA = null;
		markerB = null;
		decorationService = null;
	}
}
