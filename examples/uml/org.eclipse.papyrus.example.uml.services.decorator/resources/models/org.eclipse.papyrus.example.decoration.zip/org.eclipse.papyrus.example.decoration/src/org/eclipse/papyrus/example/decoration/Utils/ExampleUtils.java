/*****************************************************************************
 * Copyright (c) 2015 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Mickael ADAM (ALL4TEC) mickael.adam@all4tec.net - Initial API and Implementation
 *****************************************************************************/
package org.eclipse.papyrus.example.decoration.Utils;

import org.eclipse.emf.common.util.EList;
import org.eclipse.uml2.uml.Abstraction;
import org.eclipse.uml2.uml.CallBehaviorAction;
import org.eclipse.uml2.uml.NamedElement;
import org.eclipse.uml2.uml.PackageableElement;
import org.eclipse.uml2.uml.Stereotype;


/**
 * This utilize provide some methods and constants used on decorators examples.
 *
 */
public class ExampleUtils {

	/** The NodeA stereotype qualify name */
	public static final String NODE_A_STEREOTYPE = "DecorationExampleProfile::NodeA"; //$NON-NLS-1$

	/** The NodeB stereotype qualify name */
	public static final String NODE_B_STEREOTYPE = "DecorationExampleProfile::NodeB"; //$NON-NLS-1$

	/**
	 * Test if the <i>behavior</i> is allocated to a element which its stereotype QualifyName is <i>stereotype</i>.
	 * 
	 * @param behavoir
	 *            the behavior the test
	 * @param Stereotype
	 *            the stereotype qualify name as string
	 * @return true if the client behavoir have a supplier with the good stereotype.
	 */
	public static Boolean isAllocatedTo(final CallBehaviorAction behavoir, final String Stereotype) {
		Boolean result = false;

		// Test if the behavoir s allocated with the specfic nodes stereotyped A or B
		final EList<PackageableElement> packagedElements = behavoir.getModel().getPackagedElements();
		// For each allocation
		for (final PackageableElement element : packagedElements) {
			if (element instanceof Abstraction) {
				// ((Abstraction) element);
				if (((Abstraction) element).getClients().contains(behavoir)) {
					final EList<NamedElement> suppliers = ((Abstraction) element).getSuppliers();
					for (final NamedElement supplier : suppliers) {
						// Get appled stereotype of supplier
						final EList<Stereotype> appliedStereotypes = supplier.getAppliedStereotypes();
						for (final Stereotype stereotype : appliedStereotypes) {
							if (Stereotype.equals(stereotype.getQualifiedName())) {// $NON-NLS-1$
								result = true;
							}
						}
					}
				}
			}
		}
		return result;
	}
}
