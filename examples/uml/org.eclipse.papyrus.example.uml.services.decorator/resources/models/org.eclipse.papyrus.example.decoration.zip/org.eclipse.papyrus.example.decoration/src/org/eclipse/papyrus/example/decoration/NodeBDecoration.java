/*****************************************************************************
 * Copyright (c) 2015 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Mickael ADAM (ALL4TEC) mickael.adam@all4tec.net - Initial API and Implementation
 *****************************************************************************/

package org.eclipse.papyrus.example.decoration;

import org.eclipse.emf.common.util.EList;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.papyrus.infra.services.decoration.IDecorationSpecificFunctions;
import org.eclipse.papyrus.infra.services.decoration.util.Decoration.PreferedPosition;
import org.eclipse.papyrus.infra.services.decoration.util.IPapyrusDecoration;
import org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker;

/**
 * Example of Implementation of {@link IDecorationSpecificFunctions} from Papyrus decoration service to decoration nodeB.
 */
public class NodeBDecoration implements IDecorationSpecificFunctions {

	/**
	 * 
	 * @see org.eclipse.papyrus.infra.services.decoration.IDecorationSpecificFunctions#supportsMarkerPropagation()
	 *
	 * @return null since it doesn't support propagation here
	 */
	@Override
	public MarkChildren supportsMarkerPropagation() {
		// This marker should not be propagated
		return null;
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.decoration.IDecorationSpecificFunctions#markerPropagation(org.eclipse.emf.common.util.EList)
	 *
	 * @param childDecorations
	 * @return null since it doesn't support propagation here
	 */
	@Override
	public IPapyrusDecoration markerPropagation(final EList<IPapyrusDecoration> childDecorations) {
		// This marker should not be propagated
		return null;
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.decoration.IDecorationSpecificFunctions#getImageDescriptorForGE(org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker)
	 *
	 * @param marker
	 * @return image Descriptor
	 */
	@Override
	public ImageDescriptor getImageDescriptorForGE(final IPapyrusMarker marker) {
		return org.eclipse.papyrus.infra.widgets.Activator.getDefault().getImageDescriptor(Activator.ID, "icons/NodeB.gif"); //$NON-NLS-1$
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.decoration.IDecorationSpecificFunctions#getImageDescriptorForME(org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker)
	 *
	 * @param marker
	 * @return null since we don't manage image in ME on this example.
	 */
	@Override
	public ImageDescriptor getImageDescriptorForME(final IPapyrusMarker marker) {
		// This decorator only applies to GMF elements
		return null;
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.decoration.IDecorationSpecificFunctions#getPreferedPosition(org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker)
	 *
	 * @param marker
	 * @return the prefered position.
	 */
	@Override
	public PreferedPosition getPreferedPosition(final IPapyrusMarker marker) {
		return PreferedPosition.SOUTH_WEST;
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.decoration.IDecorationSpecificFunctions#getMessage(org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker)
	 *
	 * @param marker
	 * @return the message
	 */
	@Override
	public String getMessage(final IPapyrusMarker marker) {
		return "Node B decoration example";
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.decoration.IDecorationSpecificFunctions#getPriority(org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker)
	 *
	 * @param marker
	 * @return the priority
	 */
	@Override
	public int getPriority(final IPapyrusMarker marker) {
		return 0;
	}

}
