/*****************************************************************************
 * Copyright (c) 2015 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Mickael ADAM (ALL4TEC) mickael.adam@all4tec.net - Initial API and Implementation
 *****************************************************************************/
package org.eclipse.papyrus.example.decoration;

import java.util.Collections;
import java.util.Map;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.papyrus.example.decoration.Utils.ExampleUtils;
import org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker;
import org.eclipse.uml2.uml.CallBehaviorAction;

/**
 * Example of Implementation of {@link IPapyrusMarker} from Papyrus decoration service to decoration nodeA through marker
 *
 */
public class NodeAMarker implements IPapyrusMarker {

	/**
	 * The marker type. Also permits to link {@link NodeBMarker} to {@link NodeBMarker} in extension point.
	 */
	public static final String MARKER_TYPE = "org.eclipse.papyrus.infra.services.decoration.example.NodeA"; //$NON-NLS-1$

	/**
	 * the notation element
	 */
	protected View notationElement;

	/**
	 * Constructor.
	 *
	 * @param notationElement
	 *            the view
	 */
	public NodeAMarker(final View notationElement) {
		this.notationElement = notationElement;
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker#getResource()
	 *
	 * @return the resource
	 */
	@Override
	public Resource getResource() {
		return notationElement.eResource();
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker#getEObject()
	 *
	 * @return the eObject
	 */
	@Override
	public EObject getEObject() {
		return notationElement;
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker#exists()
	 *
	 * @return true if the marker exist
	 */
	@Override
	public boolean exists() {
		return ExampleUtils.isAllocatedTo((CallBehaviorAction) notationElement, ExampleUtils.NODE_A_STEREOTYPE);
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker#getType()
	 *
	 * @return the type of the marker
	 * @throws CoreException
	 */
	@Override
	public String getType() throws CoreException {
		return MARKER_TYPE;
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker#getTypeLabel()
	 *
	 * @return return the label of the marker
	 * @throws CoreException
	 */
	@Override
	public String getTypeLabel() throws CoreException {
		return "Node A marker example";
	}

	/**
	 * @see org.eclipse.papyrus.infra.services.markerlistener.IPapyrusMarker#delete()
	 *
	 * @throws CoreException
	 */
	@Override
	public void delete() throws CoreException {
		// Do nothing: the user cannot manually remove the marker
	}


	// /
	// The marker doesn't have any attribute: default implementation does nothing
	// /

	@Override
	public Object getAttribute(final String name) throws CoreException {
		return null;
	}

	@Override
	public String getAttribute(final String name, final String defaultValue) {
		return defaultValue;
	}

	@Override
	public boolean getAttribute(final String name, final boolean defaultValue) {
		return defaultValue;
	}

	@Override
	public int getAttribute(final String name, final int defaultValue) {
		return defaultValue;
	}

	@Override
	public Map<String, ?> getAttributes() throws CoreException {
		return Collections.emptyMap();
	}

	@Override
	public boolean isSubtypeOf(final String type) throws CoreException {
		return false;
	}

	@Override
	public void setAttribute(final String name, final Object value) throws CoreException {
		// Nothing
	}

	@Override
	public void setAttribute(final String name, final String value) throws CoreException {
		// Nothing
	}

	@Override
	public void setAttribute(final String name, final boolean value) throws CoreException {
		// Nothing
	}

	@Override
	public void setAttribute(final String name, final int value) throws CoreException {
		// Nothing
	}

	@Override
	public void setAttributes(final Map<String, ?> attributes) throws CoreException {
		// Nothing
	}

}
