/*****************************************************************************
 * Copyright (c) 2015 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Mickael ADAM (ALL4TEC) mickael.adam@all4tec.net - Initial API and Implementation
 *****************************************************************************/
package org.eclipse.papyrus.example.decoration.provider;

import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.diagram.ui.services.decorator.CreateDecoratorsOperation;
import org.eclipse.gmf.runtime.diagram.ui.services.decorator.IDecoratorProvider;
import org.eclipse.gmf.runtime.diagram.ui.services.decorator.IDecoratorTarget;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.papyrus.example.decoration.NodeDecorator;
import org.eclipse.papyrus.uml.diagram.activity.edit.parts.ActivityDiagramEditPart;
import org.eclipse.papyrus.uml.diagram.activity.part.UMLVisualIDRegistry;
import org.eclipse.uml2.uml.CallBehaviorAction;

/**
 * Example of provider for display decoration using gmf decorator framework.
 */
public class GMFDecoratorProvider extends AbstractProvider implements IDecoratorProvider {

	// The key of the installed decorator
	private static final String GMF_DECORATION_KEY = "gmf_decoration_example_key"; //$NON-NLS-1$

	/**
	 * @see org.eclipse.gmf.runtime.common.core.service.IProvider#provides(org.eclipse.gmf.runtime.common.core.service.IOperation)
	 *
	 * @param operation
	 *            the operation
	 * @return true if it provide a decorator for the operation
	 */
	@Override
	public boolean provides(final IOperation operation) {
		boolean provide = false;
		// it needs to be a CreateDecoratorsOperation
		if (operation instanceof CreateDecoratorsOperation) {
			final IDecoratorTarget decoratorTarget = ((CreateDecoratorsOperation) operation).getDecoratorTarget();
			final View view = decoratorTarget.getAdapter(View.class);

			// Test if the decoratorTarget element is a CallBehavoirAction
			if (null != view && ActivityDiagramEditPart.MODEL_ID.equals(UMLVisualIDRegistry.getModelID(view)) && view.getElement() instanceof CallBehaviorAction) {
				provide = true;
			} else {
				provide = false;
			}
		}
		return provide;
	}

	/**
	 * @see org.eclipse.gmf.runtime.diagram.ui.services.decorator.IDecoratorProvider#createDecorators(org.eclipse.gmf.runtime.diagram.ui.services.decorator.IDecoratorTarget)
	 *
	 * @param decoratorTarget
	 *            the decoratorTarget
	 */
	@Override
	public void createDecorators(final IDecoratorTarget decoratorTarget) {
		final View node = decoratorTarget.getAdapter(View.class);
		if (node != null) {
			// Install the decorator
			decoratorTarget.installDecorator(GMF_DECORATION_KEY, new NodeDecorator(decoratorTarget));
		}
	}
}
