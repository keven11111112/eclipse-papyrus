package org.eclipse.papyrus.example.decoration;


import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.FlowLayout;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.Locator;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.GraphicalEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.diagram.ui.services.decorator.AbstractDecorator;
import org.eclipse.gmf.runtime.diagram.ui.services.decorator.IDecoratorTarget;
import org.eclipse.gmf.runtime.diagram.ui.services.decorator.IDecoratorTarget.Direction;
import org.eclipse.gmf.runtime.draw2d.ui.mapmode.IMapMode;
import org.eclipse.gmf.runtime.draw2d.ui.mapmode.MapModeUtil;
import org.eclipse.gmf.runtime.notation.IntValueStyle;
import org.eclipse.gmf.runtime.notation.NotationPackage;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.papyrus.example.decoration.Utils.ExampleUtils;
import org.eclipse.papyrus.example.decoration.locators.InsideDirectedLocator;
import org.eclipse.papyrus.infra.gmfdiag.common.editpart.NodeEditPart;
import org.eclipse.papyrus.uml.diagram.common.figure.node.ScaledImageFigure;
import org.eclipse.swt.graphics.Image;
import org.eclipse.uml2.uml.CallBehaviorAction;


/**
 * Decorators for nodeA and nodeB manage with GMF framework.
 */
public class NodeDecorator extends AbstractDecorator {

	// The image width
	private static final int IMAGE_WIDTH = 16;
	// The image height
	private static final int IMAGE_HEIGHT = 16;

	/**
	 * Constructor.
	 *
	 * @param decoratorTarget
	 */
	public NodeDecorator(final IDecoratorTarget decoratorTarget) {
		super(decoratorTarget);
	}

	/**
	 * @see org.eclipse.gmf.runtime.diagram.ui.services.decorator.IDecorator#activate()
	 *
	 */
	@Override
	public void activate() {
		// TODO install listener on allocation(Abstraction) of the model.
		refresh();
	}

	/**
	 * @see org.eclipse.gmf.runtime.diagram.ui.services.decorator.IDecorator#refresh()
	 *
	 */
	@Override
	public void refresh() {
		// First of all, we remove decoration
		removeDecoration();
		final EditPart editPart = (EditPart) getDecoratorTarget().getAdapter(EditPart.class);
		if (editPart instanceof NodeEditPart) {
			// Get the figure of the editpart
			final IFigure editPartFigure = ((GraphicalEditPart) editPart).getFigure();
			// Get the view of the editpart
			final View view = (View) editPart.getModel();

			// Create a main figure with a flow layout. It will contains others images.
			final IFigure figure = new Figure();
			final FlowLayout flowLayout = new FlowLayout();
			flowLayout.setHorizontal(true);
			flowLayout.setMinorSpacing(0);
			figure.setLayoutManager(flowLayout);


			// If for nodeA is allocated to the call behavior
			if (ExampleUtils.isAllocatedTo((CallBehaviorAction) view.getElement(), ExampleUtils.NODE_A_STEREOTYPE)) {
				// Create child figure
				final ScaledImageFigure imageFigureA = getImageNode("icons/NodeA.gif");//$NON-NLS-1$
				// Add it to main figure of the decoration
				figure.add(imageFigureA);
			}
			// If for nodeA is allocated to the call behavior
			if (ExampleUtils.isAllocatedTo((CallBehaviorAction) view.getElement(), ExampleUtils.NODE_B_STEREOTYPE)) {
				// Create child figure
				final ScaledImageFigure imageFigureB = getImageNode("icons/NodeB.gif");//$NON-NLS-1$
				// Add it to main figure of the decoration
				figure.add(imageFigureB);
			}

			// Get MapMode
			final IMapMode mm = MapModeUtil.getMapMode(editPartFigure);
			// Set the size of the decorator figure
			figure.setSize(mm.DPtoLP(IMAGE_WIDTH * figure.getChildren().size()) + 2, mm.DPtoLP(IMAGE_HEIGHT));

			// Get the direction/position of the decoration.
			// Direction will be takes from shape direction in appearance tab of properties view.
			final Direction direction = getDirection(view);

			// Set the decoration without locator: position managed by GMF.
			// setDecoration(getDecoratorTarget().addShapeDecoration(figure, direction, -1, false));

			// Instantiate a custom locator to have decoration inside the figure
			final Locator locator = new InsideDirectedLocator(editPartFigure, direction);
			// Set the decoration with the custom locator.
			setDecoration(getDecoratorTarget().addDecoration(figure, locator, false));

			// set the tooltip
			getDecoration().setToolTip(new Label("GMF Decorations"));
		}
	}

	/**
	 * Create a ScaledImageFigure for a specific relative location of a image.
	 * 
	 * @param imageLocation
	 * @return the image.
	 */
	private ScaledImageFigure getImageNode(final String imageLocation) {
		final ImageDescriptor imageDescriptor = org.eclipse.papyrus.infra.widgets.Activator.getDefault().getImageDescriptor(Activator.ID, imageLocation);
		final Image image = imageDescriptor.createImage();
		final ScaledImageFigure imageFigure = new ScaledImageFigure();
		imageFigure.setImage(image);
		imageFigure.setSize(IMAGE_WIDTH, IMAGE_HEIGHT);
		return imageFigure;
	}


	/**
	 * Get the direction/position of the node. Direction will be takes from shape direction in appearance tab of properties view, used normally for shape
	 * 
	 * @param node
	 * @return the direction
	 */
	protected Direction getDirection(final View node) {
		final String SHAPE_DECORATOR_DIRECTION = "shapeDirection"; //$NON-NLS-1$

		final IGraphicalEditPart gep = (IGraphicalEditPart) getDecoratorTarget().getAdapter(IGraphicalEditPart.class);
		assert gep != null;
		// get the custom style for the direction
		final IntValueStyle directionStyle = (IntValueStyle) node.getNamedStyle(NotationPackage.eINSTANCE.getIntValueStyle(), SHAPE_DECORATOR_DIRECTION);
		if (directionStyle != null) {
			final int direction = directionStyle.getIntValue();
			switch (direction) {
			case 0: // NORTH WEST
				return IDecoratorTarget.Direction.NORTH_WEST;
			case 1: // NORTH
				return IDecoratorTarget.Direction.NORTH;
			case 2: // NORTH EAST
				return IDecoratorTarget.Direction.NORTH_EAST;
			case 3: // WEST
				return IDecoratorTarget.Direction.WEST;
			case 4: // CENTER
				return IDecoratorTarget.Direction.CENTER;
			case 5: // EAST
				return IDecoratorTarget.Direction.EAST;
			case 6: // SOUTH WEST
				return IDecoratorTarget.Direction.SOUTH_WEST;
			case 7: // SOUTH
				return IDecoratorTarget.Direction.SOUTH;
			case 8: // SOUTH EAST
				return IDecoratorTarget.Direction.SOUTH_EAST;
			default:
				return IDecoratorTarget.Direction.NORTH_WEST;
			}
		}
		return IDecoratorTarget.Direction.NORTH_WEST;
	}
}
